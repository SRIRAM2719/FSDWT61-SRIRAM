import PropTypes from 'prop-types';

export default function Square(props) {
    return <div className = "square" > {
            props.label
        } <
        /div>
}

Square.propTypes = {
    label: PropTypes.string
};