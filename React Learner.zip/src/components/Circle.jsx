import React from "react";
import PropTypes from 'prop-types';

// Class Component
class Circle extends React.Component {
    // Normal constructor
    constructor(props) {
        // Super constructor
        super(props);
    }
    // Lifecycle methods
    render() {
        return < >
            <
            div className = "circle" > {
                this.props.label
            } < /div> <
            />   
    }
}

Circle.propTypes = {
    label: PropTypes.string
};

export default Circle;