import {
    useState
} from 'react'

export default function Counter() {
    const [count, setCount] = useState(0);

    function handleAdd() {
        setCount(count + 1);
    }

    function handleSubtract() {
        setCount(count - 1);
    }

    return ( <
        > {
            count > 10 ?
            <
            div className = "error-banner" >
            Count exceeded 10 <
            /div> : null} <
            h1 id = "count" > {
                count
            } < /h1> <
            button onClick = {
                handleAdd
            } > Add < /button> <
            button onClick = {
                handleSubtract
            }
            disabled = {
                count < 1
            } > Subtract < /button> <
            />
        )
    }