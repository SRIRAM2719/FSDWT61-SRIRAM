import './App.css'
import Square from "./components/Square";

// Function Component
function App() {
  const data = [{
    label: "Vishnu"
  }, {
    label: "Lokesh"
  }, {
    label: "Premasuriyan"
  }];
  return ( < > {
      data.map((el, index) => < Square key = {
          `${el.label}-${index}`
        }
        label = {
          el.label
        }
        /> )
      } <
      />
    )
  }

  export default App;